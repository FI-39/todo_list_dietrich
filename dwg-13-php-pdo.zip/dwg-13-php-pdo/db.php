<pre>
<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once './php/classes/class.database.php';

echo "\n";
echo "\n";


$db = new Databaseconnection('fi39', 'j23d', 'beep');
$result = $db->selectTableData('staffmember', '*', '');
var_dump($result);
echo "\n";
echo "\n";


$result = $db->selectTableData('staffmember', 'username, email', '');
var_dump($result);
echo "\n";
echo "\n";


$result = $db->selectTableData('staffmember', 'username, role', ' where role=\'Admin\'');
var_dump($result);
echo "\n";
echo "\n";

$result = $db->insertTableData('staffmember', "('10000', 'elli', '123435', 'elli@elli.com', '0', 'Member')");
var_dump($result);
echo "\n";
echo "\n";


$db = null;
?>
</pre>